package ai.venice.chesshelper.native

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class HelperService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val EXTRA_RESULT = "result"
        const val SCALE = 0.45f
        const val INTERVAL = 700L

        var overlay: OverlayView? = null
        var onPosition: ((Position) -> Unit)? = null
        var onCleared: (() -> Unit)? = null
    }

    data class Position(val fen: String, val left: Int, val top: Int, val size: Int, val flipped: Boolean) {
        fun toMap(): Map<String, Any> = mapOf(
            "fen" to fen, "left" to left, "top" to top, "size" to size, "flipped" to flipped
        )
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val ui = Handler(Looper.getMainLooper())
    private val work = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private val recognizer = BoardRecognizer()
    private var lastFen = ""
    private var running = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForegroundCompat()
                intent.getParcelableExtra<Intent>(EXTRA_RESULT)?.let { begin(it) }
            }
            ACTION_STOP -> { shutdown(); stopSelf() }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("helper", "chess helper", NotificationManager.IMPORTANCE_LOW))
        val n = android.app.Notification.Builder(this, "helper")
            .setContentTitle("helper running")
            .setContentText("reading the board")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun begin(result: Intent) {
        running = true
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * SCALE).toInt()
        val h = (dm.heightPixels * SCALE).toInt()
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        projection = getSystemService(MediaProjectionManager::class.java).getMediaProjection(-1, result)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { shutdown() }
        }, ui)
        display = projection?.createVirtualDisplay(
            "cap", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, ui
        )
        val view = OverlayView(this)
        view.attach()
        overlay = view
        ui.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            grab()
            ui.postDelayed(this, INTERVAL)
        }
    }

    private fun grab() {
        if (busy.get()) return
        val img = reader?.acquireLatestImage() ?: return
        try {
            val w = img.width
            val h = img.height
            val plane = img.planes[0]
            val pad = plane.rowStride - plane.pixelStride * w
            val raw = Bitmap.createBitmap(w + pad / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
            raw.copyPixelsFromBuffer(plane.buffer)
            val shot = Bitmap.createBitmap(raw, 0, 0, w, h)
            busy.set(true)
            work.execute {
                try {
                    val rec = recognizer.read(shot)
                    if (rec == null) {
                        ui.post { overlay?.clear(); onCleared?.invoke() }
                        return@execute
                    }
                    if (rec.fen == lastFen) return@execute
                    lastFen = rec.fen
                    ui.post {
                        overlay?.setBoard(rec.rect.left, rec.rect.top, rec.rect.width(), rec.flipped)
                        onPosition?.invoke(Position(rec.fen, rec.rect.left, rec.rect.top, rec.rect.width(), rec.flipped))
                    }
                } finally { busy.set(false) }
            }
        } finally { img.close() }
    }

    private fun shutdown() {
        running = false
        ui.removeCallbacks(tick)
        overlay?.detach(); overlay = null
        display?.release(); display = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
        if (!work.isShutdown) work.shutdown()
        onCleared?.invoke()
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        shutdown(); stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (running) shutdown()
    }
}
