package ai.venice.chesshelper.native

import android.graphics.Bitmap
import android.graphics.Rect

/** Screenshot -> FEN. Board geometry first, then per-square ink analysis. */
class BoardRecognizer {

    data class Rec(val fen: String, val rect: Rect, val flipped: Boolean)

    fun read(bmp: Bitmap): Rec? {
        val rect = findBoard(bmp) ?: return null
        val cell = rect.width() / 8f
        if (cell < 12f) return null

        val ink = FloatArray(64)
        for (i in 0 until 64) {
            val f = i % 8
            val r = i / 8
            ink[i] = inkRatio(bmp, rect.left + ((f + 0.5f) * cell).toInt(), rect.top + ((r + 0.5f) * cell).toInt(), (cell * 0.30f).toInt())
        }

        val sorted = ink.sorted()
        val floor = sorted[sorted.size / 6]
        val thresh = floor + (sorted[sorted.size * 5 / 6] - floor) * 0.35f + 0.02f

        val occ = BooleanArray(64)
        var count = 0
        for (i in 0 until 64) if (ink[i] > thresh) { occ[i] = true; count++ }
        if (count < 4 || count > 32) return null

        val flipped = detectSide(bmp, rect, cell, occ) ?: return null
        val fen = buildFen(bmp, rect, cell, occ, flipped) ?: return null
        return Rec(fen, rect, flipped)
    }

    private fun detectSide(bmp: Bitmap, rect: Rect, cell: Float, occ: BooleanArray): Boolean? {
        var white = 0
        var black = 0
        for (i in 48 until 64) {
            if (!occ[i]) continue
            val f = i % 8
            val r = i / 8
            if (luminance(bmp, rect.left + ((f + 0.5f) * cell).toInt(), rect.top + ((r + 0.5f) * cell).toInt()) > 0.62f) white++ else black++
        }
        if (white == 0 && black == 0) return null
        return black > white
    }

    private fun buildFen(bmp: Bitmap, rect: Rect, cell: Float, occ: BooleanArray, flipped: Boolean): String? {
        var kings = 0
        val rows = arrayOfNulls<String>(8)
        for (boardRow in 0 until 8) {
            val sb = StringBuilder()
            var run = 0
            for (boardFile in 0 until 8) {
                val sf = if (flipped) 7 - boardFile else boardFile
                val sr = if (flipped) boardRow else 7 - boardRow
                val i = sr * 8 + sf
                if (!occ[i]) { run++; continue }
                if (run > 0) { sb.append(run); run = 0 }
                val cx = rect.left + ((sf + 0.5f) * cell).toInt()
                val cy = rect.top + ((sr + 0.5f) * cell).toInt()
                val p = classify(bmp, cx, cy, cell, luminance(bmp, cx, cy) > 0.62f)
                if (p == 'k' || p == 'K') kings++
                sb.append(p)
            }
            if (run > 0) sb.append(run)
            rows[boardRow] = sb.toString()
        }
        if (kings != 2) return null
        val fen = StringBuilder()
        for (r in 7 downTo 0) {
            fen.append(rows[r])
            if (r > 0) fen.append('/')
        }
        fen.append(if (flipped) " b " else " w ").append("- - 0 1")
        return fen.toString()
    }

    private fun classify(bmp: Bitmap, cx: Int, cy: Int, cell: Float, white: Boolean): Char {
        val r = (cell * 0.34f).toInt()
        var sumY = 0.0
        var n = 0
        var top = 0
        var bot = 0
        var wide = 0
        var y = -r
        while (y <= r) {
            var x = -r
            while (x <= r) {
                val px = cx + x
                val py = cy + y
                if (px >= 0 && py >= 0 && px < bmp.width && py < bmp.height) {
                    val l = luminance(bmp, px, py)
                    if (if (white) l > 0.66f else l < 0.42f) {
                        n++
                        sumY += y
                        if (y < -r / 3) top++ else if (y > r / 3) bot++
                        if (x < -r / 2 || x > r / 2) wide++
                    }
                }
                x += 2
            }
            y += 2
        }
        val c = if (n == 0) 0.0 else sumY / n
        val spread = n.toFloat() / 400f
        val t = when {
            spread < 0.16f && c > -1.5 -> 1
            wide * 4 > n * 3 -> 4
            c < -r * 0.16 -> 2
            spread < 0.34f -> 3
            top * 3 > bot * 4 -> 5
            else -> 1
        }
        val ch = when (t) { 1 -> 'p'; 2 -> 'n'; 3 -> 'b'; 4 -> 'r'; 5 -> 'q'; else -> 'k' }
        return if (white) ch.uppercaseChar() else ch
    }

    private fun inkRatio(bmp: Bitmap, cx: Int, cy: Int, r: Int): Float {
        var lit = 0
        var n = 0
        var y = -r
        while (y <= r) {
            var x = -r
            while (x <= r) {
                val px = cx + x
                val py = cy + y
                if (px >= 0 && py >= 0 && px < bmp.width && py < bmp.height) {
                    val l = luminance(bmp, px, py)
                    if (l > 0.62f || l < 0.42f) lit++
                    n++
                }
                x += 2
            }
            y += 2
        }
        return if (n == 0) 0f else lit.toFloat() / n
    }

    private fun luminance(bmp: Bitmap, x: Int, y: Int): Float {
        if (x < 0 || y < 0 || x >= bmp.width || y >= bmp.height) return 0f
        val c = bmp.getPixel(x, y)
        return (0.299f * ((c shr 16) and 255) + 0.587f * ((c shr 8) and 255) + 0.114f * (c and 255)) / 255f
    }

    private fun findBoard(bmp: Bitmap): Rect? {
        val w = bmp.width
        val h = bmp.height
        var best: Rect? = null
        var bestWidth = 0
        val step = (h / 200).coerceAtLeast(6)
        var y = (h * 0.12f).toInt()
        while (y < (h * 0.92f).toInt()) {
            val row = alternation(bmp, y)
            if (row != null && row.width() > bestWidth && row.width() >= w * 0.5f) {
                val top = (y - row.width() / 2).coerceIn(0, h - 1)
                val bottom = (top + row.width()).coerceIn(1, h)
                if (bottom - top >= row.width() * 0.92f) {
                    bestWidth = row.width()
                    best = Rect(row.left, top, row.right, bottom)
                }
            }
            y += step
        }
        return best
    }

    private fun alternation(bmp: Bitmap, y: Int): Rect? {
        var prev = -1
        var flips = 0
        var start = 0
        var left = -1
        var right = -1
        for (x in 0 until bmp.width) {
            val l = luminance(bmp, x, y)
            val band = when { l > 0.6f -> 1; l < 0.45f -> 0; else -> -1 }
            if (band == -1) continue
            if (prev == -1) { prev = band; start = x; continue }
            if (band != prev) {
                flips++
                prev = band
                if (flips >= 6) { left = start; right = x }
            }
        }
        if (flips < 6 || left < 0) return null
        return Rect(left, y, right, y)
    }
}
