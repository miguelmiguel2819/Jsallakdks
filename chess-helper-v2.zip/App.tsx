import { useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as Helper from './modules/chess-helper-native';
import { bestMove, moveTo64 } from './src/engine/search';

export default function App() {
  const [on, setOn] = useState(false);
  const [note, setNote] = useState('off');
  const busy = useRef(false);

  useEffect(() => {
    const a = Helper.onPosition((p) => {
      if (busy.current) return;
      busy.current = true;
      try {
        const m = bestMove(p.fen, 1500);
        if (m) {
          const [from, to] = moveTo64(m);
          Helper.drawMove(from, to);
        }
      } finally {
        busy.current = false;
      }
    });
    const b = Helper.onCleared(() => Helper.clear());
    return () => {
      a.remove();
      b.remove();
    };
  }, []);

  async function toggle() {
    if (on) {
      await Helper.stop();
      setOn(false);
      setNote('off');
      return;
    }
    if (!(await Helper.canOverlay())) {
      await Helper.askOverlay();
      setNote('grant overlay, then tap again');
      return;
    }
    await Helper.start();
    setOn(true);
    setNote('running');
  }

  return (
    <View style={s.root}>
      <StatusBar style="light" />
      <Text style={s.note}>{note}</Text>
      <Pressable onPress={toggle} style={[s.ring, on ? s.ringOn : null]}>
        <Text style={[s.label, on ? s.labelOn : null]}>{on ? 'ON' : 'OFF'}</Text>
      </Pressable>
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0b0d10', alignItems: 'center', justifyContent: 'center' },
  note: { color: '#6b7280', fontSize: 13, marginBottom: 28 },
  ring: {
    width: 150,
    height: 150,
    borderRadius: 75,
    borderWidth: 2,
    borderColor: '#2a3038',
    backgroundColor: '#14181d',
    alignItems: 'center',
    justifyContent: 'center',
  },
  ringOn: { borderColor: '#22c55e', backgroundColor: '#12261a' },
  label: { color: '#e5e7eb', fontSize: 20, letterSpacing: 2 },
  labelOn: { color: '#22c55e' },
});
