const { withAndroidManifest } = require('expo/config-plugins');

const PERMISSIONS = [
  'android.permission.SYSTEM_ALERT_WINDOW',
  'android.permission.FOREGROUND_SERVICE',
  'android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION',
  'android.permission.POST_NOTIFICATIONS',
];

module.exports = function withChessHelper(config) {
  return withAndroidManifest(config, (cfg) => {
    const manifest = cfg.modResults.manifest;
    manifest['uses-permission'] = manifest['uses-permission'] || [];
    const present = new Set(manifest['uses-permission'].map((p) => p.$['android:name']));
    for (const p of PERMISSIONS) {
      if (!present.has(p)) manifest['uses-permission'].push({ $: { 'android:name': p } });
    }

    const app = manifest.application[0];
    app.service = app.service || [];
    if (!app.service.some((s) => s.$['android:name'].endsWith('HelperService'))) {
      app.service.push({
        $: {
          'android:name': 'ai.venice.chesshelper.nativemod.HelperService',
          'android:exported': 'false',
          'android:foregroundServiceType': 'mediaProjection',
        },
      });
    }
    return cfg;
  });
};
