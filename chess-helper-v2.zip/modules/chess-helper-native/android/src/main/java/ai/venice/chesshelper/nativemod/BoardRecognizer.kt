package ai.venice.chesshelper.nativemod

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs

/**
 * Screenshot -> FEN. The board is found by the rhythm of its squares, occupancy by the
 * difference from each square's own background, and piece types by templates that are
 * learned automatically whenever the starting position is on screen.
 */
class BoardRecognizer {

    data class Rec(val fen: String, val rect: Rect, val flipped: Boolean)

    var status = ""
    var dirty = false

    private val g = 12
    private val tpl = HashMap<String, FloatArray>()
    private var w = 0
    private var h = 0
    private var y = FloatArray(0)

    fun exportTemplates(): String {
        val sb = StringBuilder()
        for ((k, v) in tpl) {
            sb.append(k).append('=')
            for (i in v.indices) {
                if (i > 0) sb.append(',')
                sb.append(v[i])
            }
            sb.append(';')
        }
        return sb.toString()
    }

    fun importTemplates(s: String) {
        try {
            for (part in s.split(';')) {
                if (part.isEmpty()) continue
                val kv = part.split('=')
                val nums = kv[1].split(',')
                if (nums.size != g * g) continue
                tpl[kv[0]] = FloatArray(g * g) { nums[it].toFloat() }
            }
        } catch (e: Exception) {
            tpl.clear()
        }
    }

    fun read(bmp: Bitmap): Rec? {
        w = bmp.width
        h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        y = FloatArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            y[i] = (0.299f * ((c shr 16) and 255) + 0.587f * ((c shr 8) and 255) + 0.114f * (c and 255)) / 255f
        }
        val rect = findBoard()
        if (rect == null) {
            status = "no board found"
            return null
        }
        val cell = rect.width() / 8f
        val occ = BooleanArray(64)
        val white = BooleanArray(64)
        val vec = arrayOfNulls<FloatArray>(64)
        var count = 0
        for (i in 0 until 64) {
            val x0 = rect.left + (i % 8) * cell
            val y0 = rect.top + (i / 8) * cell
            val bg = background(x0, y0, cell)
            val m = FloatArray(g * g)
            val cnt = IntArray(g * g)
            var ink = 0
            var tot = 0
            val a = (cell * 0.08f).toInt()
            val e = (cell * 0.92f).toInt()
            val span = e - a
            for (yy in a until e) {
                for (xx in a until e) {
                    val l = lum((x0 + xx).toInt(), (y0 + yy).toInt())
                    val gi = ((yy - a) * g / span) * g + (xx - a) * g / span
                    cnt[gi]++
                    tot++
                    if (abs(l - bg) > 0.2f) ink++
                    if (l < bg - 0.2f) m[gi] += 1f
                }
            }
            if (tot == 0 || ink.toFloat() / tot < 0.06f) continue
            for (k in m.indices) if (cnt[k] > 0) m[k] /= cnt[k]
            occ[i] = true
            count++
            vec[i] = m
            val cl = ArrayList<Float>()
            val c0 = (cell * 0.35f).toInt()
            val c1 = (cell * 0.65f).toInt()
            var cy = c0
            while (cy < c1) {
                var cx = c0
                while (cx < c1) {
                    cl.add(lum((x0 + cx).toInt(), (y0 + cy).toInt()))
                    cx += 2
                }
                cy += 2
            }
            cl.sort()
            white[i] = cl[cl.size / 2] > 0.5f
        }
        if (count < 2 || count > 32) {
            status = "board found but $count pieces"
            return null
        }

        var wb = 0
        var bb = 0
        for (i in 32 until 64) {
            if (!occ[i]) continue
            if (white[i]) wb++ else bb++
        }
        if (wb + bb == 0) {
            status = "cannot tell your colour"
            return null
        }
        val flipped = bb > wb

        if (isStart(occ)) learn(vec, white, flipped)
        if (tpl.isEmpty()) {
            status = "start a new game so I can learn the pieces"
            return null
        }

        val rows = arrayOfNulls<String>(8)
        var kings = 0
        for (boardRow in 0 until 8) {
            val sb = StringBuilder()
            var run = 0
            for (boardFile in 0 until 8) {
                val sf = if (flipped) 7 - boardFile else boardFile
                val sr = if (flipped) boardRow else 7 - boardRow
                val i = sr * 8 + sf
                if (!occ[i]) {
                    run++
                    continue
                }
                if (run > 0) {
                    sb.append(run)
                    run = 0
                }
                val p = nearest(vec[i]!!, white[i])
                if (p == 'K' || p == 'k') kings++
                sb.append(p)
            }
            if (run > 0) sb.append(run)
            rows[boardRow] = sb.toString()
        }
        if (kings != 2) {
            status = "read $kings kings, retrying"
            return null
        }
        val fen = StringBuilder()
        for (r in 7 downTo 0) {
            fen.append(rows[r])
            if (r > 0) fen.append('/')
        }
        fen.append(if (flipped) " b " else " w ").append("- - 0 1")
        status = "board ok"
        return Rec(fen.toString(), rect, flipped)
    }

    private fun isStart(occ: BooleanArray): Boolean {
        for (i in 0 until 64) {
            val r = i / 8
            if (occ[i] != (r < 2 || r > 5)) return false
        }
        return true
    }

    private fun learn(vec: Array<FloatArray?>, white: BooleanArray, flipped: Boolean): Boolean {
        val back = if (flipped) "RNBKQBNR" else "RNBQKBNR"
        val sums = HashMap<String, FloatArray>()
        val ns = HashMap<String, Int>()
        for (i in 0 until 64) {
            val r = i / 8
            val c = i % 8
            if (r in 2..5) continue
            val bottomSide = r > 5
            val isWhite = if (flipped) !bottomSide else bottomSide
            if (white[i] != isWhite) return false
            val ch = if (r == 0 || r == 7) back[c] else 'P'
            val key = (if (isWhite) "w:" else "b:") + ch
            val s = sums.getOrPut(key) { FloatArray(g * g) }
            val v = vec[i] ?: return false
            for (j in v.indices) s[j] += v[j]
            ns[key] = (ns[key] ?: 0) + 1
        }
        for ((k, s) in sums) {
            val n = ns[k] ?: 1
            tpl[k] = FloatArray(s.size) { s[it] / n }
        }
        dirty = true
        return true
    }

    private fun nearest(v: FloatArray, white: Boolean): Char {
        var best = 'P'
        var bd = Float.MAX_VALUE
        for (k in "PNBRQK") {
            val t = tpl[(if (white) "w:" else "b:") + k] ?: continue
            var d = 0f
            for (j in v.indices) {
                val q = v[j] - t[j]
                d += q * q
            }
            if (d < bd) {
                bd = d
                best = k
            }
        }
        return if (white) best else best.lowercaseChar()
    }

    private fun lum(x: Int, yy: Int): Float =
        if (x < 0 || yy < 0 || x >= w || yy >= h) 0f else y[yy * w + x]

    private fun background(x0: Float, y0: Float, cell: Float): Float {
        val inset = cell * 0.08f
        val span = cell - 2 * inset
        val list = ArrayList<Float>()
        var t = 0f
        while (t <= span) {
            list.add(lum((x0 + inset + t).toInt(), (y0 + inset).toInt()))
            list.add(lum((x0 + inset + t).toInt(), (y0 + cell - inset).toInt()))
            list.add(lum((x0 + inset).toInt(), (y0 + inset + t).toInt()))
            list.add(lum((x0 + cell - inset).toInt(), (y0 + inset + t).toInt()))
            t += 2f
        }
        list.sort()
        return list[list.size / 2]
    }

    private fun edges(start: Int, stride: Int, n: Int): IntArray {
        val out = ArrayList<Int>()
        var last = -10
        for (k in 2 until n - 2) {
            val d = abs(y[start + (k + 1) * stride] - y[start + (k - 1) * stride])
            if (d > 0.07f) {
                if (k - last > 3) out.add(k)
                last = k
            }
        }
        return out.toIntArray()
    }

    /** Longest run of evenly spaced edges (7 to 9 of them). Returns [first, last, count]. */
    private fun chain(e: IntArray, expect: Float, minD: Float): IntArray? {
        var best: IntArray? = null
        for (i in e.indices) {
            for (j in i + 1 until minOf(i + 3, e.size)) {
                val d = (e[j] - e[i]).toFloat()
                if (d < minD) continue
                if (expect > 0f && abs(d - expect) > expect * 0.12f) continue
                var pos = e[i]
                var cnt = 1
                var idx = i
                while (cnt < 9) {
                    var nxt = -1
                    for (k in idx + 1 until e.size) {
                        if (abs(e[k] - (pos + d)) <= d * 0.12f) {
                            nxt = k
                            break
                        }
                        if (e[k] > pos + d * 1.2f) break
                    }
                    if (nxt < 0) break
                    pos = e[nxt]
                    idx = nxt
                    cnt++
                }
                val b = best
                if (cnt >= 7 && (b == null || cnt > b[2])) best = intArrayOf(e[i], pos, cnt)
            }
        }
        return best
    }

    private fun findBoard(): Rect? {
        var bestChain: IntArray? = null
        var row = (h * 0.08f).toInt()
        while (row < (h * 0.95f).toInt()) {
            val ch = chain(edges(row * w, 1, w), 0f, w / 18f)
            val b = bestChain
            if (ch != null && (b == null || ch[2] > b[2])) bestChain = ch
            row += 2
        }
        val hc = bestChain ?: return null
        val cell = (hc[1] - hc[0]).toFloat() / (hc[2] - 1)
        var left = hc[0].toFloat()
        if (hc[2] == 7) left -= cell
        if (hc[2] == 8) {
            val a = left - cell
            if (abs(a + cell * 4 - w / 2f) < abs(left + cell * 4 - w / 2f)) left = a
        }
        if (cell * 8 < w * 0.45f || left < -2f || left + cell * 8 > w + 2f) return null

        var bestV: IntArray? = null
        var col = left.toInt() + 2
        val colEnd = (left + cell * 8).toInt() - 2
        while (col < colEnd) {
            if (col in 0 until w) {
                val ch = chain(edges(col, w, h), cell, cell * 0.6f)
                val b = bestV
                if (ch != null && (b == null || ch[2] > b[2])) bestV = ch
            }
            col += 2
        }
        val vc = bestV ?: return null
        var top = vc[0].toFloat()
        if (vc[2] == 7) top -= cell
        if (vc[2] == 8) {
            val a = top - cell
            if (abs(a + cell * 4 - h * 0.45f) < abs(top + cell * 4 - h * 0.45f)) top = a
        }
        if (top < -2f || top + cell * 8 > h + 2f) return null
        return Rect(left.toInt(), top.toInt(), (left + cell * 8).toInt(), (top + cell * 8).toInt())
    }
}
