package ai.venice.chesshelper.nativemod

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.provider.Settings
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class ChessHelperModule : Module() {

    private val requestCode = 4711

    override fun definition() = ModuleDefinition {
        Name("ChessHelper")
        Events("onPosition", "onCleared")

        AsyncFunction("canOverlay") {
            val ctx = appContext.reactContext ?: return@AsyncFunction false
            Settings.canDrawOverlays(ctx)
        }

        AsyncFunction("askOverlay") {
            val ctx = appContext.reactContext ?: return@AsyncFunction null
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }

        AsyncFunction("start") {
            val activity = appContext.currentActivity ?: return@AsyncFunction null
            val mgr = activity.getSystemService(MediaProjectionManager::class.java)
            activity.startActivityForResult(mgr.createScreenCaptureIntent(), requestCode)
        }

        AsyncFunction("stop") {
            val ctx = appContext.reactContext ?: return@AsyncFunction null
            ctx.startService(Intent(ctx, HelperService::class.java).apply { action = HelperService.ACTION_STOP })
        }

        Function("drawMove") { from: Int, to: Int ->
            HelperService.overlay?.show(from, to)
        }

        Function("clear") {
            HelperService.overlay?.clear()
        }

        OnActivityResult { _, payload ->
            if (payload.requestCode != requestCode) return@OnActivityResult
            if (payload.resultCode != Activity.RESULT_OK) return@OnActivityResult
            val data = payload.data ?: return@OnActivityResult
            val ctx = appContext.reactContext ?: return@OnActivityResult
            val i = Intent(ctx, HelperService::class.java).apply {
                action = HelperService.ACTION_START
                putExtra(HelperService.EXTRA_RESULT, data)
            }
            ctx.startForegroundService(i)
            HelperService.onPosition = { p -> sendEvent("onPosition", p.toMap()) }
            HelperService.onCleared = { sendEvent("onCleared") }
        }
    }
}
