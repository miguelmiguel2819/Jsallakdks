import { requireNativeModule, EventEmitter } from 'expo-modules-core';

export type Position = {
  fen: string;
  left: number;
  top: number;
  size: number;
  flipped: boolean;
};

const Native = requireNativeModule('ChessHelper');
const emitter = new EventEmitter(Native);

export function canOverlay(): Promise<boolean> {
  return Native.canOverlay();
}

export function askOverlay(): Promise<void> {
  return Native.askOverlay();
}

export function start(): Promise<void> {
  return Native.start();
}

export function stop(): Promise<void> {
  return Native.stop();
}

export function drawMove(from: number, to: number): void {
  Native.drawMove(from, to);
}

export function clear(): void {
  Native.clear();
}

export function onPosition(fn: (p: Position) => void) {
  return emitter.addListener('onPosition', fn);
}

export function onCleared(fn: () => void) {
  return emitter.addListener('onCleared', fn);
}
