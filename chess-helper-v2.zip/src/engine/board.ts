export const WHITE = 0;
export const BLACK = 8;
export const PAWN = 1;
export const KNIGHT = 2;
export const BISHOP = 3;
export const ROOK = 4;
export const QUEEN = 5;
export const KING = 6;

export const FL_CAP = 1;
export const FL_EP = 2;
export const FL_CAST = 4;
export const FL_DBL = 8;

const KN = [-21, -19, -12, -8, 8, 12, 19, 21];
const KG = [-11, -10, -9, -1, 1, 9, 10, 11];

let seed = 0x2f6e2b1;
function rnd(): number {
  seed ^= seed << 13;
  seed ^= seed >>> 17;
  seed ^= seed << 5;
  return seed | 0;
}

const ZP: Int32Array[] = [];
for (let p = 0; p < 15; p++) {
  const row = new Int32Array(120);
  for (let s = 0; s < 120; s++) row[s] = rnd();
  ZP.push(row);
}
const ZCAST = new Int32Array(16);
for (let i = 0; i < 16; i++) ZCAST[i] = rnd();
const ZEP = new Int32Array(120);
for (let s = 0; s < 120; s++) ZEP[s] = rnd();
const ZSIDE = rnd();

export const onB = (s: number) => s >= 21 && s <= 98;
export const fileOf = (s: number) => (s % 10) - 1;
export const rankOf = (s: number) => Math.floor(s / 10) - 2;

export class Board {
  sq = new Uint8Array(120);
  side = WHITE;
  castle = 0;
  ep = 0;
  half = 0;
  hash = 0;

  private undoCap = new Int32Array(256);
  private undoMove = new Int32Array(256);
  private undoCastle = new Int32Array(256);
  private undoEp = new Int32Array(256);
  private undoHalf = new Int32Array(256);
  private undoHash = new Int32Array(256);
  private keys = new Int32Array(1024);
  private keyCount = 0;
  private ply = 0;

  setFen(fen: string) {
    this.sq.fill(0);
    this.castle = 0;
    this.ep = 0;
    this.half = 0;
    this.hash = 0;
    this.ply = 0;
    this.keyCount = 0;

    const parts = fen.trim().split(/\s+/);
    let r = 7;
    let c = 0;
    for (const ch of parts[0]) {
      if (ch === '/') { r--; c = 0; continue; }
      if (ch >= '1' && ch <= '8') { c += +ch; continue; }
      const low = ch.toLowerCase();
      const t = 'pnbrqk'.indexOf(low) + 1;
      const col = ch === low ? BLACK : WHITE;
      const s = (r + 2) * 10 + c + 1;
      this.sq[s] = t | col;
      this.hash ^= ZP[t | col][s];
      c++;
    }
    if (parts[1] === 'b') { this.hash ^= ZSIDE; this.side = BLACK; } else this.side = WHITE;
    const cr = parts[2] || '-';
    if (cr.includes('K')) this.castle |= 1;
    if (cr.includes('Q')) this.castle |= 2;
    if (cr.includes('k')) this.castle |= 4;
    if (cr.includes('q')) this.castle |= 8;
    this.hash ^= ZCAST[this.castle];
    this.keys[0] = this.hash;
    this.keyCount = 1;
  }

  kingSq(c: number): number {
    for (let s = 21; s <= 98; s++) if (this.sq[s] === (KING | c)) return s;
    return 0;
  }

  attacked(s: number, by: number): boolean {
    const po = by === WHITE ? [-9, -11] : [9, 11];
    for (const o of po) {
      const t = s + o;
      if (onB(t) && this.sq[t] === (PAWN | by)) return true;
    }
    for (const o of KN) {
      const t = s + o;
      if (onB(t) && this.sq[t] === (KNIGHT | by)) return true;
    }
    for (const o of KG) {
      const t = s + o;
      if (onB(t) && this.sq[t] === (KING | by)) return true;
    }
    for (const o of [-11, -9, 9, 11]) {
      let t = s + o;
      while (onB(t)) {
        const p = this.sq[t];
        if (p) {
          if (p === (BISHOP | by) || p === (QUEEN | by)) return true;
          break;
        }
        t += o;
      }
    }
    for (const o of [-10, -1, 1, 10]) {
      let t = s + o;
      while (onB(t)) {
        const p = this.sq[t];
        if (p) {
          if (p === (ROOK | by) || p === (QUEEN | by)) return true;
          break;
        }
        t += o;
      }
    }
    return false;
  }

  inCheck(c: number) { return this.attacked(this.kingSq(c), c ^ 8); }

  gen(capOnly: boolean, out: Int32Array): number {
    const us = this.side;
    const them = us ^ 8;
    let n = 0;
    for (let s = 21; s <= 98; s++) {
      const p = this.sq[s];
      if (!p || (p & 8) !== us) continue;
      const t = p & 7;

      if (t === PAWN) {
        const push = us === WHITE ? s + 10 : s - 10;
        if (!capOnly && onB(push) && !this.sq[push]) {
          if (rankOf(push) === 7 || rankOf(push) === 0) {
            for (const pr of [QUEEN, ROOK, BISHOP, KNIGHT]) out[n++] = s | (push << 8) | (pr << 20);
          } else {
            out[n++] = s | (push << 8);
            const dbl = us === WHITE ? s + 20 : s - 20;
            if (!this.sq[dbl] && ((us === WHITE && rankOf(s) === 1) || (us === BLACK && rankOf(s) === 6))) {
              out[n++] = s | (dbl << 8) | (FL_DBL << 16);
            }
          }
        }
        for (const o of us === WHITE ? [9, 11] : [-9, -11]) {
          const to = s + o;
          if (!onB(to)) continue;
          if (this.sq[to] && (this.sq[to] & 8) === them) {
            if (rankOf(to) === 7 || rankOf(to) === 0) {
              for (const pr of [QUEEN, ROOK, BISHOP, KNIGHT]) out[n++] = s | (to << 8) | (FL_CAP << 16) | (pr << 20);
            } else out[n++] = s | (to << 8) | (FL_CAP << 16);
          } else if (!capOnly && to === this.ep && !this.sq[to]) {
            out[n++] = s | (to << 8) | ((FL_CAP | FL_EP) << 16);
          }
        }
      } else if (t === KNIGHT || t === KING) {
        for (const o of t === KNIGHT ? KN : KG) {
          const to = s + o;
          if (!onB(to)) continue;
          const q = this.sq[to];
          if (q && (q & 8) === us) continue;
          if (capOnly && !q) continue;
          out[n++] = s | (to << 8) | (q ? FL_CAP << 16 : 0);
        }
        if (t === KING && !capOnly) {
          if (us === WHITE) {
            if (this.castle & 1 && !this.sq[26] && !this.sq[27] && this.sq[25] === (KING | WHITE) &&
              !this.attacked(25, BLACK) && !this.attacked(26, BLACK) && !this.attacked(27, BLACK)) out[n++] = 25 | (27 << 8) | (FL_CAST << 16);
            if (this.castle & 2 && !this.sq[24] && !this.sq[23] && !this.sq[22] && this.sq[25] === (KING | WHITE) &&
              !this.attacked(25, BLACK) && !this.attacked(24, BLACK) && !this.attacked(23, BLACK)) out[n++] = 25 | (23 << 8) | (FL_CAST << 16);
          } else {
            if (this.castle & 4 && !this.sq[96] && !this.sq[97] && this.sq[95] === (KING | BLACK) &&
              !this.attacked(95, WHITE) && !this.attacked(96, WHITE) && !this.attacked(97, WHITE)) out[n++] = 95 | (97 << 8) | (FL_CAST << 16);
            if (this.castle & 8 && !this.sq[94] && !this.sq[93] && !this.sq[92] && this.sq[95] === (KING | BLACK) &&
              !this.attacked(95, WHITE) && !this.attacked(94, WHITE) && !this.attacked(93, WHITE)) out[n++] = 95 | (93 << 8) | (FL_CAST << 16);
          }
        }
      } else {
        const dirs = t === BISHOP ? [-11, -9, 9, 11] : t === ROOK ? [-10, -1, 1, 10] : [-11, -10, -9, -1, 1, 9, 10, 11];
        for (const o of dirs) {
          let to = s + o;
          while (onB(to)) {
            const q = this.sq[to];
            if (q && (q & 8) === us) break;
            if (!capOnly || q) out[n++] = s | (to << 8) | (q ? FL_CAP << 16 : 0);
            if (q) break;
            to += o;
          }
        }
      }
    }
    return n;
  }

  make(m: number): boolean {
    const from = m & 255;
    const to = (m >> 8) & 255;
    const flag = (m >> 16) & 15;
    const promo = (m >> 20) & 15;
    const pc = this.sq[from];
    const us = pc & 8;
    const type = pc & 7;
    const capSq = flag & FL_EP ? (us === WHITE ? to - 10 : to + 10) : to;
    const cap = this.sq[capSq];

    this.undoCap[this.ply] = cap;
    this.undoMove[this.ply] = m;
    this.undoCastle[this.ply] = this.castle;
    this.undoEp[this.ply] = this.ep;
    this.undoHalf[this.ply] = this.half;
    this.undoHash[this.ply] = this.hash;
    this.ply++;

    this.hash ^= ZP[pc][from];
    this.sq[from] = 0;
    if (cap) { this.hash ^= ZP[cap][capSq]; this.sq[capSq] = 0; }
    this.sq[to] = promo ? promo | us : pc;
    this.hash ^= ZP[this.sq[to]][to];

    if (this.ep) { this.hash ^= ZEP[this.ep]; this.ep = 0; }
    if (flag & FL_DBL) { this.ep = us === WHITE ? from + 10 : from - 10; this.hash ^= ZEP[this.ep]; }

    if (type === KING) {
      if (us === WHITE) this.castle &= ~3; else this.castle &= ~12;
      if (flag & FL_CAST) {
        if (to === 27) { this.sq[28] = 0; this.sq[26] = ROOK | WHITE; this.hash ^= ZP[ROOK | WHITE][28] ^ ZP[ROOK | WHITE][26]; }
        if (to === 23) { this.sq[21] = 0; this.sq[24] = ROOK | WHITE; this.hash ^= ZP[ROOK | WHITE][21] ^ ZP[ROOK | WHITE][24]; }
        if (to === 97) { this.sq[98] = 0; this.sq[96] = ROOK | BLACK; this.hash ^= ZP[ROOK | BLACK][98] ^ ZP[ROOK | BLACK][96]; }
        if (to === 93) { this.sq[91] = 0; this.sq[94] = ROOK | BLACK; this.hash ^= ZP[ROOK | BLACK][91] ^ ZP[ROOK | BLACK][94]; }
      }
    }
    if (type === ROOK || cap === (ROOK | WHITE) || cap === (ROOK | BLACK)) {
      if (from === 21 || to === 21) this.castle &= ~2;
      if (from === 28 || to === 28) this.castle &= ~1;
      if (from === 91 || to === 91) this.castle &= ~8;
      if (from === 98 || to === 98) this.castle &= ~4;
    }
    this.hash ^= ZCAST[this.undoCastle[this.ply - 1]] ^ ZCAST[this.castle];

    this.half = type === PAWN || cap ? 0 : this.half + 1;
    this.side ^= 8;
    this.hash ^= ZSIDE;

    if (this.attacked(this.kingSq(us), this.side ^ 8)) { this.unmake(); return false; }
    if (this.keyCount < 1024) this.keys[this.keyCount++] = this.hash;
    return true;
  }

  unmake() {
    if (this.ply === 0) return;
    this.ply--;
    const m = this.undoMove[this.ply];
    const from = m & 255;
    const to = (m >> 8) & 255;
    const flag = (m >> 16) & 15;
    const promo = (m >> 20) & 15;
    const pc = this.sq[to];
    const us = pc & 8;
    const type = pc & 7;

    this.sq[from] = promo ? type | us : pc;
    this.sq[to] = 0;
    if (this.undoCap[this.ply]) {
      this.sq[flag & FL_EP ? (us === WHITE ? to - 10 : to + 10) : to] = this.undoCap[this.ply];
    }
    this.castle = this.undoCastle[this.ply];
    this.ep = this.undoEp[this.ply];
    this.half = this.undoHalf[this.ply];
    this.hash = this.undoHash[this.ply];
    this.side ^= 8;
    if (this.keyCount > 0) this.keyCount--;
    if (flag & FL_CAST) {
      if (to === 27) { this.sq[26] = 0; this.sq[28] = ROOK | WHITE; }
      if (to === 23) { this.sq[24] = 0; this.sq[21] = ROOK | WHITE; }
      if (to === 97) { this.sq[96] = 0; this.sq[98] = ROOK | BLACK; }
      if (to === 93) { this.sq[94] = 0; this.sq[91] = ROOK | BLACK; }
    }
  }

  isRepetition(): boolean {
    let i = this.keyCount - 3;
    const stop = Math.max(0, this.keyCount - 1 - this.half);
    while (i >= stop) {
      if (this.keys[i] === this.hash) return true;
      i -= 2;
    }
    return false;
  }

  sane(): boolean {
    let wk = 0, bk = 0, n = 0;
    for (let s = 21; s <= 98; s++) {
      const p = this.sq[s];
      if (!p) continue;
      n++;
      if (p === (KING | WHITE)) wk++;
      if (p === (KING | BLACK)) bk++;
    }
    return wk === 1 && bk === 1 && n >= 3 && n <= 32;
  }
}

export const to64 = (s: number) => rankOf(s) * 8 + fileOf(s);
