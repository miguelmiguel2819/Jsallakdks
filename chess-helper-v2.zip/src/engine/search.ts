import { Board, FL_CAP, to64 } from './board';
import { evaluate } from './eval';

const MATE = 30000;
const MAX_PLY = 64;
const TT_SIZE = 1 << 20;
const TT_MASK = TT_SIZE - 1;

export function bestMove(fen: string, limitMs: number): number {
  const b = new Board();
  b.setFen(fen);
  if (!b.sane()) return 0;

  const ttKey = new Int32Array(TT_SIZE);
  const ttMove = new Int32Array(TT_SIZE);
  const ttScore = new Int32Array(TT_SIZE);
  const ttDepth = new Int8Array(TT_SIZE);
  const ttFlag = new Uint8Array(TT_SIZE);

  const killers = new Int32Array(MAX_PLY * 2);
  const history = new Int32Array(120 * 120);
  const moveBuf: Int32Array[] = [];
  const scoreBuf: Int32Array[] = [];
  for (let i = 0; i < MAX_PLY; i++) {
    moveBuf.push(new Int32Array(256));
    scoreBuf.push(new Int32Array(256));
  }

  let nodes = 0;
  let stopped = false;
  let bestRoot = 0;
  const deadline = Date.now() + limitMs;

  const mvvLva = (m: number) => {
    const to = (m >> 8) & 255;
    const from = m & 255;
    const cap = b.sq[to];
    const vic = cap ? cap & 7 : b.sq[from] & 7;
    return (((m >> 20) & 15) ? 9000 : 0) + vic * 16 - (b.sq[from] & 7);
  };

  function quiesce(alpha0: number, beta: number, ply: number): number {
    let alpha = alpha0;
    if ((nodes & 1023) === 0 && Date.now() > deadline) stopped = true;
    nodes++;
    if (ply >= MAX_PLY - 2) return evaluate(b);
    const stand = evaluate(b);
    if (stand >= beta) return beta;
    if (stand > alpha) alpha = stand;

    const moves = moveBuf[ply];
    const scores = scoreBuf[ply];
    const n = b.gen(true, moves);
    for (let i = 0; i < n; i++) scores[i] = mvvLva(moves[i]);

    for (let i = 0; i < n; i++) {
      let bi = i;
      for (let j = i + 1; j < n; j++) if (scores[j] > scores[bi]) bi = j;
      if (bi !== i) {
        const tm = moves[i]; moves[i] = moves[bi]; moves[bi] = tm;
        const ts = scores[i]; scores[i] = scores[bi]; scores[bi] = ts;
      }
      const m = moves[i];
      if (!b.make(m)) continue;
      const v = -quiesce(-beta, -alpha, ply + 1);
      b.unmake();
      if (stopped) return alpha;
      if (v >= beta) return beta;
      if (v > alpha) alpha = v;
    }
    return alpha;
  }

  function search(depth: number, alpha0: number, beta: number, ply: number, pvNode: boolean): number {
    let alpha = alpha0;
    if (ply > 0 && b.isRepetition()) return 0;
    if (b.half >= 100) return 0;
    if (ply >= MAX_PLY - 2) return evaluate(b);
    if ((nodes & 1023) === 0 && Date.now() > deadline) stopped = true;
    if (stopped && ply > 0) return alpha;
    nodes++;

    const inCheck = b.inCheck(b.side);
    if (inCheck) depth++;
    if (depth <= 0) return quiesce(alpha, beta, ply);

    const idx = b.hash & TT_MASK;
    let ttM = 0;
    if (ttKey[idx] === b.hash) {
      ttM = ttMove[idx];
      if (!pvNode && ttDepth[idx] >= depth) {
        let s = ttScore[idx];
        if (s > MATE - 1000) s -= ply;
        else if (s < -MATE + 1000) s += ply;
        const f = ttFlag[idx];
        if (f === 1) return s;
        if (f === 2 && s >= beta) return beta;
        if (f === 3 && s <= alpha) return alpha;
      }
    }

    const staticEval = inCheck ? -99999 : evaluate(b);

    if (!pvNode && !inCheck) {
      if (depth <= 2 && staticEval >= beta) return beta;
      if (depth >= 3 && staticEval >= beta) {
        const savedEp = b.ep;
        b.ep = 0;
        b.hash ^= 0;
        b.side ^= 8;
        const v = -search(depth - 3, -beta, -beta + 1, ply + 1, false);
        b.side ^= 8;
        b.ep = savedEp;
        if (!stopped && v >= beta) return beta;
      }
    }

    const moves = moveBuf[ply];
    const scores = scoreBuf[ply];
    const n = b.gen(false, moves);
    for (let i = 0; i < n; i++) {
      const m = moves[i];
      if (m === ttM) scores[i] = 10000000;
      else if ((m >> 16) & FL_CAP) scores[i] = 1000000 + mvvLva(m);
      else if (m === killers[ply * 2]) scores[i] = 900000;
      else if (m === killers[ply * 2 + 1]) scores[i] = 800000;
      else scores[i] = history[((m & 255) * 120) + ((m >> 8) & 255)];
    }

    let best = -MATE;
    let legal = 0;
    let flag = 3;
    let bestLocal = 0;

    for (let i = 0; i < n; i++) {
      let bi = i;
      for (let j = i + 1; j < n; j++) if (scores[j] > scores[bi]) bi = j;
      if (bi !== i) {
        const tm = moves[i]; moves[i] = moves[bi]; moves[bi] = tm;
        const ts = scores[i]; scores[i] = scores[bi]; scores[bi] = ts;
      }
      const m = moves[i];
      const isCap = !!((m >> 16) & FL_CAP);
      if (!b.make(m)) continue;
      legal++;
      let v: number;
      if (legal === 1) {
        v = -search(depth - 1, -beta, -alpha, ply + 1, true);
      } else {
        let red = 0;
        if (depth >= 3 && legal > 3 && !isCap && !inCheck) red = 1 + (legal > 8 ? 1 : 0);
        v = -search(depth - 1 - red, -alpha - 1, -alpha, ply + 1, false);
        if (v > alpha && red > 0) v = -search(depth - 1, -alpha - 1, -alpha, ply + 1, false);
        if (v > alpha) v = -search(depth - 1, -beta, -alpha, ply + 1, true);
      }
      b.unmake();
      if (stopped && ply > 0) return alpha;
      if (v > best) {
        best = v;
        bestLocal = m;
        if (v > alpha) {
          alpha = v;
          flag = 1;
          if (ply === 0) bestRoot = m;
          if (v >= beta) {
            if (!isCap) {
              if (killers[ply * 2] !== m) {
                killers[ply * 2 + 1] = killers[ply * 2];
                killers[ply * 2] = m;
              }
              history[((m & 255) * 120) + ((m >> 8) & 255)] += depth * depth;
            }
            flag = 2;
            break;
          }
        }
      }
    }

    if (legal === 0) return inCheck ? -MATE + ply : 0;

    let store = best;
    if (store > MATE - 1000) store += ply;
    else if (store < -MATE + 1000) store -= ply;
    ttKey[idx] = b.hash;
    ttMove[idx] = bestLocal;
    ttScore[idx] = store;
    ttDepth[idx] = depth;
    ttFlag[idx] = flag;
    return best;
  }

  let prev = 0;
  for (let d = 1; d < MAX_PLY - 2; d++) {
    let alpha = d <= 4 ? -MATE : prev - 40;
    let beta = d <= 4 ? MATE : prev + 40;
    let v = 0;
    for (;;) {
      v = search(d, alpha, beta, 0, true);
      if (stopped) break;
      if (v <= alpha) alpha -= 120;
      else if (v >= beta) beta += 120;
      else break;
    }
    if (stopped && d > 1) break;
    prev = v;
    if (Math.abs(v) > MATE - 500) break;
    if (Date.now() > deadline) break;
  }

  return bestRoot;
}

export function moveTo64(m: number): [number, number] {
  return [to64(m & 255), to64((m >> 8) & 255)];
}
