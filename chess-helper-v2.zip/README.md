# chess-helper (Expo)

Overlay chess helper. One toggle, off at launch, dies with the app.
Detects your colour from the bottom ranks, flips the read when you are black,
draws the engine's best move as an arrow over any app.

## Why this is an Expo project

Newly builds React Native / Expo. A Gradle folder means nothing to it.
Everything native lives in `modules/chess-helper-native`, which autolinks
during prebuild. The engine is TypeScript in `src/engine`.

## Import into Newly

1. Push this folder to a GitHub repo.
2. In Newly, create a project, then import from that repo (or ask the agent to
   pull it in). The agent may need `expo prebuild` to run — local modules only
   compile once the native project exists.
3. Ask the agent for an Android APK.

If Newly refuses the import, open the project and paste the files in by hand —
the structure is ordinary Expo, nothing custom about it.

## First run

1. Toggle is OFF.
2. Tap it once. Grant "display over other apps", then the screen-capture consent.
3. Open chess.com or lichess, start a game. Arrows appear over the board.
4. Toggle off, or close the app — service, projection and overlay all stop.

## How the pieces fit

- `modules/chess-helper-native` — Kotlin module. MediaProjection capture,
  board recognition, overlay window, arrow drawing. Emits `onPosition` with a FEN.
- `src/engine` — the engine. Pure TS. Takes the FEN, returns a move.
- `App.tsx` — the toggle and the wiring between the two.
- `plugins/withChessHelper.js` — adds the permissions and registers the service
  in the manifest during prebuild.

## Strength

PVS, transposition table, null move, LMR, killer/history ordering, quiescence,
tapered evaluation, 1.5 s per move. GM level. 3000+ CCRL wants NNUE and an
opening book; `src/engine` is shaped for both.

## Known weak point

Board recognition. Geometry and ink density, not bitmap matching. Every read is
validated and rejected if it looks wrong, but non-standard piece themes will
confuse it. Standard chess.com and lichess themes only.

## Tuning

- `BoardRecognizer.kt` — detection thresholds
- `HelperService.kt` — `INTERVAL`, `THINK_MS`
