package ai.venice.chesshelper.nativemod

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

@SuppressLint("ViewConstructor")
class OverlayView(private val ctx: Context) : View(ctx) {

    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = 0xFFF59E0B.toInt()
    }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFF59E0B.toInt()
    }

    private var from = PointF()
    private var to = PointF()
    private var has = false
    private var boardLeft = 0f
    private var boardTop = 0f
    private var boardSize = 0f
    private var flipped = false

    fun attach() {
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        runCatching { wm.addView(this, p) }
    }

    fun detach() { runCatching { wm.removeView(this) } }

    fun clear() { has = false; invalidate() }

    fun setBoard(left: Int, top: Int, size: Int, isFlipped: Boolean) {
        boardLeft = left.toFloat()
        boardTop = top.toFloat()
        boardSize = size.toFloat()
        flipped = isFlipped
    }

    fun show(from64: Int, to64: Int) {
        if (boardSize <= 0f) return
        val cell = boardSize / 8f
        from = center(from64, cell)
        to = center(to64, cell)
        has = true
        invalidate()
    }

    private fun center(sq: Int, cell: Float): PointF {
        val f = sq % 8
        val r = sq / 8
        val sf = if (flipped) 7 - f else f
        val sr = if (flipped) r else 7 - r
        return PointF(boardLeft + (sf + 0.5f) * cell, boardTop + (sr + 0.5f) * cell)
    }

    override fun onDraw(canvas: Canvas) {
        if (!has) return
        val dx = to.x - from.x
        val dy = to.y - from.y
        val len = hypot(dx, dy)
        if (len < 4f) return
        val ux = dx / len
        val uy = dy / len
        val sx = from.x + ux * len * 0.22f
        val sy = from.y + uy * len * 0.22f
        val ex = to.x - ux * len * 0.2f
        val ey = to.y - uy * len * 0.2f
        paint.strokeWidth = len * 0.075f
        canvas.drawLine(sx, sy, ex, ey, paint)
        val ang = atan2(ey - sy, ex - sx)
        val hl = len * 0.17f
        val path = Path()
        path.moveTo(ex, ey)
        path.lineTo(ex - hl * cos(ang - 0.45f), ey - hl * sin(ang - 0.45f))
        path.lineTo(ex - hl * cos(ang + 0.45f), ey - hl * sin(ang + 0.45f))
        path.close()
        canvas.drawPath(path, head)
    }
}
